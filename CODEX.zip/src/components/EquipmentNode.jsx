import { Handle, Position } from '@xyflow/react'

function EquipmentNode({ data, id }) {
  const decks = data.decks || 0
  const isScreen = data.equipmentType === 'screen'
  const isProductPile = data.equipmentType === 'productPile'
  const isFeedPile = data.equipmentType === 'feedPile'

  function handleConnectorClick(event, handleId) {
    event.stopPropagation()

    data.onConnectorClick?.(
      id,
      handleId
    )
  }

  return (
    <div className="equipment-node">
        {isFeedPile && (
  <div className="equipment-description equipment-description-top">
    {data.description}
  </div>
)}
      <div className="equipment-visual">
        <img
  src={data.image}
  alt={data.label}
  className={`equipment-image equipment-image-${data.equipmentType}`}
/>

        {data.inputFlow &&
  data.hasConnectionOnHandle?.(id, 'entrada') && (
          <div
            style={{
              position: 'absolute',
              left: '64%',
              top: '-18px',
              transform: 'translateX(-50%)',
              fontSize: '12px',
              fontWeight: 'bold',
              whiteSpace: 'nowrap',
              pointerEvents: 'none',
              zIndex: 10,
            }}
          >
            {data.inputFlow}
          </div>
        )}

        {data.bottomOutputFlow &&
  !isProductPile &&
  data.hasConnectionOnHandle?.(id, 'saida-inferior') && (
          <div
            style={{
              position: 'absolute',
              left: '62%',
              bottom: '-18px',
              transform: 'translateX(-50%)',
              fontSize: '12px',
              fontWeight: 'bold',
              whiteSpace: 'nowrap',
              pointerEvents: 'none',
              zIndex: 10,
            }}
          >
            {data.bottomOutputFlow}
          </div>
        )}

{data.lateralOutputFlow &&
  data.hasConnectionOnHandle?.(id, 'saida-lateral') && (
  <div
    style={{
      position: 'absolute',
      left: '105%',
      top: '28px',
      transform: 'translateY(-50%)',
      fontSize: '12px',
      fontWeight: 'bold',
      whiteSpace: 'nowrap',
      pointerEvents: 'none',
      zIndex: 10,
    }}
  >
    {data.lateralOutputFlow}
  </div>
)}

        {!isFeedPile && (
  <Handle
    type="source"
    position={Position.Top}
    id="entrada"
    onClick={(event) =>
      handleConnectorClick(event, 'entrada')
    }
  />
)}

        {!isProductPile && (
          <Handle
            type="source"
            position={Position.Bottom}
            id="saida-inferior"
            onClick={(event) =>
              handleConnectorClick(event, 'saida-inferior')
            }
          />
        )}

{(data.equipmentType === 'feeder' ||
  data.equipmentType === 'scalper') && (
  <Handle
  type="source"
  position={Position.Right}
  id="saida-lateral"
  style={{
    top: '40px',
  }}
  onClick={(event) =>
    handleConnectorClick(event, 'saida-lateral')
  }
/>
)}

        {isScreen &&
          Array.from({ length: decks }).map((_, index) => {
            const deckId = `deck-${index + 1}`

            return (
              <div key={deckId}>
                <Handle
                  type="source"
                  position={Position.Right}
                  id={deckId}
                  style={{
                    top: `${32 + index * 18}px`,
                  }}
                  onClick={(event) =>
                    handleConnectorClick(event, deckId)
                  }
                />

                {data.deckFlows?.[deckId] &&
  data.hasConnectionOnHandle?.(id, deckId) && (
                  <div
                    style={{
                      position: 'absolute',
                      left: '105%',
                      top: `${23 + index * 18}px`,
                      transform: 'translateY(-50%)',
                      fontSize: '12px',
                      fontWeight: 'bold',
                      whiteSpace: 'nowrap',
                      pointerEvents: 'none',
                    }}
                  >
                    {data.deckFlows[deckId]}
                  </div>
                )}
              </div>
            )
          })}
      </div>

      {data.equipmentType === 'productPile' ? (
  <div className="equipment-description equipment-description-bottom">
    {data.description}
  </div>
) : !isFeedPile ? (
  <div
  className={`equipment-description ${
    isScreen &&
    Object.values(data.deckFlows || {}).some((value) => value)
      ? 'equipment-description-shifted'
      : ''
  }`}
  style={{
  width: data.descriptionWidth
    ? `${data.descriptionWidth}px`
    : 'fit-content',
  position: 'absolute',
  right: '100%',
  marginRight: '10px',
}}
>
  {data.description}
</div>
) : null}
    </div>
  )
}

export default EquipmentNode